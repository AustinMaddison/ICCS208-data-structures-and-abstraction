package Lecture3;

public class Feline {
    public int w = 0;

    public static void update(Feline f, int y){
        f.w = f.w + 42;
        y = y + 42;
    }
}
