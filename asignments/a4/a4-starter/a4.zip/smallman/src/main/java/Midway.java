public class Midway {
    public static long stepsRemaining(int[] diskPos) {
        return -1; // TODO: change me
    }
}
