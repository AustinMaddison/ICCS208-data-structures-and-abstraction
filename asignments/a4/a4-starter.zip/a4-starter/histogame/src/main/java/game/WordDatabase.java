package game;

import java.util.List;

// HINT(s):
//   To read from src/resources/<filename>
//   InputStream is = getClass().getClassLoader().getResourceAsStream(filename);

public class WordDatabase implements IDatabase {
    @Override
    public void add(Word w) {
        // TODO:
    }

    @Override
    public void remove(Word w) {
        // TODO:
    }

    @Override
    public List<Word> getWordWithLength(int l) {
        // TODO:
        return null;
    }

    @Override
    public List<Word> getAllSubWords(Word w, int minLen) {
        // TODO:
        return null;
    }

    @Override
    public boolean contains(Word o) {
        // TODO:
        return false;
    }
}
