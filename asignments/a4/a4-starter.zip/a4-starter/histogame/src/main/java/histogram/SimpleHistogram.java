package histogram;

import java.util.Iterator;

// TODO: Uncomment this and make sure to implement all the methods
/*
public class SimpleHistogram<DT> implements Histogram<DT>, Iterable<DT> {
}
 */
