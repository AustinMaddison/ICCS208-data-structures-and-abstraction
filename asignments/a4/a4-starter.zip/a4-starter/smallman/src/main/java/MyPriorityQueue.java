import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class MyPriorityQueue<T> implements IPriorityQueue<T> {
    private List<T> queueItems;

    public MyPriorityQueue(CompareWith<T> cc) {
    }

    @Override
    public void add(T item) {
    }

    @Override
    public void addAll(List<T> items) {
    }

    @Override
    public T getMinimum() {
        return null;
    }

    @Override
    public void removeMinimum() {
    }

    @Override
    public int size() {
        return 0;
    }

    @Override
    public Iterator<T> iterator() {
        return null;
    }

    @Override
    public Iterator<T> revIterator() {
        return null;
    }
}
